## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(effectbounds)

## ----data---------------------------------------------------------------------
dat <- simulate_ate_example(seed = 1, N = 5e2, alpha = 3, beta = 0.1, gamma = 1)

## ----dathead------------------------------------------------------------------
head(dat, n = 5)

## ----pscore-------------------------------------------------------------------
propensity_score_model <- glm(A ~ X1 + X2, data = dat, family = "binomial")
propensity_scores <- predict(propensity_score_model, type = "response")

## ----pscore_histogram, out.width = "100%", fig.dim = c(8, 3)------------------
par(mfrow = c(1, 2))
hist(propensity_scores, main = "Propensity scores")
hist(1 / propensity_scores, main = "Inverse propensity scores")
par(mfrow = c(1, 1))

## ----inv_pscore_histogram, out.width = "50%"----------------------------------

## ----bounds, warning = FALSE, message=FALSE-----------------------------------
set.seed(10016)
bounds <- ate_bounds(
  dat, 
  X = c("X1", "X2"), A = "A", Y = "Y", 
  thresholds = c(10^seq(-2, -0.1, 0.1)), 
  smoothness = c(0.01)
)

## ----bounds_summary-----------------------------------------------------------
summary(bounds)

## ----bounds_plot, out.width = "100%", fig.dim = c(8, 6)-----------------------
plot(bounds, point_estimate = TRUE, main = "Non-overlap ATE Bounds")

